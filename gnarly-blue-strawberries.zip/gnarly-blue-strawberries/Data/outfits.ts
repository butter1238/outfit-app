export const outfits = [
  {
    id: "1",
    title: "Casual Outfit",
    image: "https://images.pexels.com/photos/2983464/pexels-photo-2983464.jpeg",
  },
  {
    id: "2",
    title: "Formal Outfit",
    image: "https://images.unsplash.com/photo-1520975918319-6c62f9f4b9e8",
  },
  {
    id: "3",
    title: "Party Wear",
    image: "https://images.unsplash.com/photo-1520975918319-6c62f9f4b9e8",
  },
  {
    id: "4",
    title: "Sportswear",
    image:"https://images.unsplash.com/photo-1520975918319-6c62f9f4b9e8",
  },
];
