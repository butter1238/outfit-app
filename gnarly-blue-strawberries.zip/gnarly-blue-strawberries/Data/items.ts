export const items = [
  {
    id: "1",
    name: "Blue Shirt",
    category: "Top",
    image:
      "https://www.pexels.com/photo/clothes-drying-on-rope-with-clothespins-in-garden-4495705",
  },
  {
    id: "2",
    name: "Black Trousers",
    category: "Bottom",
    image:
      "https://www.pexels.com/photo/clothes-drying-on-rope-with-clothespins-in-garden-4495705",
  },
  {
    id: "3",
    name: "Brown Bag",
    category: "Accessory",
    image:
      "https://www.pexels.com/photo/clothes-drying-on-rope-with-clothespins-in-garden-4495705",
  },
  {
    id: "4",
    name: "Beige Sandals",
    category: "Footwear",
    image:
      "https://www.pexels.com/photo/clothes-drying-on-rope-with-clothespins-in-garden-4495705",
  },
];
